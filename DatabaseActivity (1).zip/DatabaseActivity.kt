package com.example.nikkiyanezeventtrackingapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DatabaseActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: EventAdapter
    private var selectedEventId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.database)

        dbHelper = DatabaseHelper(this)

        val eventNameInput = findViewById<EditText>(R.id.editTextEventName)
        val eventDateInput = findViewById<EditText>(R.id.editTextDate)
        val addEventButton = findViewById<Button>(R.id.buttonAddEvent)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewEvents)

        // --- ADDED: SETTINGS BUTTON LOGIC ---
        // This button takes the user to your notification.xml screen
        val settingsButton = findViewById<Button>(R.id.buttonSettings)
        settingsButton.setOnClickListener {
            val intent = Intent(this, NotificationActivity::class.java)
            startActivity(intent)
        }

        adapter = EventAdapter(
            events = emptyList(),
            onDelete = { id ->
                dbHelper.deleteEvent(id)
                refreshGrid()
            },
            onUpdate = { id, name, date ->
                eventNameInput.setText(name)
                eventDateInput.setText(date)
                selectedEventId = id
                addEventButton.text = "Update Event"
            }
        )

        recyclerView.layoutManager = GridLayoutManager(this, 2)
        recyclerView.adapter = adapter

        refreshGrid()

        addEventButton.setOnClickListener {
            val name = eventNameInput.text.toString()
            val date = eventDateInput.text.toString()

            if (name.isNotEmpty() && date.isNotEmpty()) {
                if (selectedEventId == -1) {
                    dbHelper.addEvent(name, date)
                    Toast.makeText(this, "Event Saved!", Toast.LENGTH_SHORT).show()

                    sendSmsAlert(name)
                } else {
                    dbHelper.updateEvent(selectedEventId, name, date)
                    selectedEventId = -1
                    addEventButton.text = "Add Event"
                }
                eventNameInput.text.clear()
                eventDateInput.text.clear()
                refreshGrid()
            }
        }
    }

    private fun sendSmsAlert(eventName: String) {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                val smsManager: SmsManager = SmsManager.getDefault()

                smsManager.sendTextMessage("5554", null, "New Event Added: $eventName", null, null)
                Toast.makeText(this, "SMS Alert Sent!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show()
            }
        } else {

            Toast.makeText(this, "SMS permission denied; alert not sent.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshGrid() {
        val cursor = dbHelper.getAllEvents()
        val eventList = mutableListOf<Triple<Int, String, String>>()
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                val date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
                eventList.add(Triple(id, name, date))
            } while (cursor.moveToNext())
        }
        cursor.close()
        adapter.refreshData(eventList)
    }
}